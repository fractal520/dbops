from time import sleep


print('begin')
sleep(20)
print('end')
